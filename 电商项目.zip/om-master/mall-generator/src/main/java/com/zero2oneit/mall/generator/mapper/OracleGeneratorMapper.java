package com.zero2oneit.mall.generator.mapper;

import org.apache.ibatis.annotations.Mapper;

/**
 * Description:
 *
 * @author Tg
 * @email zero2oneit@163.com
 * @date 2021/1/11 16:16
 */
@Mapper
public interface OracleGeneratorMapper extends GeneratorMapper {
}
