package com.zero2oneit.mall.generator.mapper;

import org.apache.ibatis.annotations.Mapper;

/**
 * Description: MySQLGeneratorMapper
 *
 * @author Tg
 * @email zero2oneit@163.com
 * @date 2021/1/11 16:14
 */
@Mapper
public interface MySQLGeneratorMapper extends GeneratorMapper {
}
